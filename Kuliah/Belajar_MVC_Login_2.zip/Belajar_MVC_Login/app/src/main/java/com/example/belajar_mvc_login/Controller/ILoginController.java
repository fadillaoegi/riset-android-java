package com.example.belajar_mvc_login.Controller;

public interface ILoginController {
    void OnLogin(String email,String Password);
}
