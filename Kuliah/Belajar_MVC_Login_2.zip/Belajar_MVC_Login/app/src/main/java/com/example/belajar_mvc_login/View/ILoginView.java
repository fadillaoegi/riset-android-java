package com.example.belajar_mvc_login.View;

public interface ILoginView {
    void OnLoginSuccess(String message);
    void OnLoginError(String message);
}
